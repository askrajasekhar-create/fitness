
import React, { useState } from 'react';
import { Exercise } from '../types';

interface ExerciseFormProps {
  onAddExercise: (exercise: Omit<Exercise, 'id'>) => void;
}

const ExerciseForm: React.FC<ExerciseFormProps> = ({ onAddExercise }) => {
  const [name, setName] = useState('');
  const [duration, setDuration] = useState('');
  const [calories, setCalories] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !duration || !calories) {
      setError('All fields are required.');
      return;
    }

    const durationNum = parseInt(duration, 10);
    const caloriesNum = parseInt(calories, 10);

    if (isNaN(durationNum) || isNaN(caloriesNum) || durationNum <= 0 || caloriesNum <= 0) {
      setError('Please enter valid positive numbers for duration and calories.');
      return;
    }

    onAddExercise({
      name: name.trim(),
      duration: durationNum,
      calories: caloriesNum,
    });
    
    setName('');
    setDuration('');
    setCalories('');
    setError('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && <p className="text-red-400 text-sm bg-red-900/50 p-3 rounded-md">{error}</p>}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">
            Exercise Name
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Running"
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition"
          />
        </div>
        <div>
          <label htmlFor="duration" className="block text-sm font-medium text-gray-300 mb-1">
            Duration (minutes)
          </label>
          <input
            type="number"
            id="duration"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            placeholder="e.g., 30"
            min="1"
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition"
          />
        </div>
        <div>
          <label htmlFor="calories" className="block text-sm font-medium text-gray-300 mb-1">
            Calories Burned
          </label>
          <input
            type="number"
            id="calories"
            value={calories}
            onChange={(e) => setCalories(e.target.value)}
            placeholder="e.g., 300"
            min="1"
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition"
          />
        </div>
      </div>
      <button
        type="submit"
        className="w-full md:w-auto bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-green-500"
      >
        Add Exercise
      </button>
    </form>
  );
};

export default ExerciseForm;
