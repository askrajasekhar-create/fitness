
import React from 'react';
import { ClockIcon } from './icons/ClockIcon';
import { FireIcon } from './icons/FireIcon';

interface SummaryProps {
  totalDuration: number;
  totalCalories: number;
}

const Summary: React.FC<SummaryProps> = ({ totalDuration, totalCalories }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="bg-gray-800 rounded-xl p-6 flex items-center space-x-4 shadow-lg transition-transform hover:scale-105">
        <div className="bg-blue-500 p-4 rounded-full">
          <ClockIcon className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-gray-400 text-sm">Total Duration</p>
          <p className="text-3xl font-bold">
            {totalDuration} <span className="text-xl font-normal text-gray-300">min</span>
          </p>
        </div>
      </div>
      <div className="bg-gray-800 rounded-xl p-6 flex items-center space-x-4 shadow-lg transition-transform hover:scale-105">
        <div className="bg-red-500 p-4 rounded-full">
          <FireIcon className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-gray-400 text-sm">Total Calories Burned</p>
          <p className="text-3xl font-bold">
            {totalCalories.toLocaleString()} <span className="text-xl font-normal text-gray-300">kcal</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Summary;
