
import React from 'react';

export const DumbbellIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    {...props}
  >
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M6.75 8.25l2.25-2.25" 
    />
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M9 6l-2.25 2.25" 
    />
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M15 15.75l2.25 2.25" 
    />
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M17.25 18l-2.25-2.25" 
    />
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M3 10.5v3m18-3v3" 
    />
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M4.5 7.5h15" 
    />
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M4.5 16.5h15" 
    />
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M6.75 12h10.5" 
    />
  </svg>
);
