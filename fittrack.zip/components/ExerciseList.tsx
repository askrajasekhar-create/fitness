
import React from 'react';
import { Exercise } from '../types';
import { ClockIcon } from './icons/ClockIcon';
import { FireIcon } from './icons/FireIcon';
import { DumbbellIcon } from './icons/DumbbellIcon';
import { TrashIcon } from './icons/TrashIcon';

interface ExerciseListProps {
  exercises: Exercise[];
  onDeleteExercise: (id: number) => void;
}

const ExerciseList: React.FC<ExerciseListProps> = ({ exercises, onDeleteExercise }) => {
  if (exercises.length === 0) {
    return (
      <div className="text-center py-10 px-4 border-2 border-dashed border-gray-700 rounded-lg">
        <DumbbellIcon className="w-12 h-12 mx-auto text-gray-500" />
        <h3 className="mt-2 text-xl font-medium text-gray-300">No exercises logged yet</h3>
        <p className="mt-1 text-sm text-gray-500">Use the form above to add your first activity!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {exercises.map((exercise) => (
        <div
          key={exercise.id}
          className="bg-gray-700/50 rounded-lg p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all hover:bg-gray-700"
        >
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-green-300 capitalize">{exercise.name}</h3>
            <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-sm text-gray-400">
              <span className="flex items-center">
                <ClockIcon className="w-4 h-4 mr-1.5 text-blue-400" />
                {exercise.duration} min
              </span>
              <span className="flex items-center">
                <FireIcon className="w-4 h-4 mr-1.5 text-red-400" />
                {exercise.calories} kcal
              </span>
            </div>
          </div>
          <button
            onClick={() => onDeleteExercise(exercise.id)}
            className="p-2 rounded-full text-gray-400 hover:text-red-400 hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-red-500 transition-colors"
            aria-label={`Delete ${exercise.name}`}
          >
            <TrashIcon className="w-5 h-5" />
          </button>
        </div>
      ))}
    </div>
  );
};

export default ExerciseList;
