
export interface Exercise {
  id: number;
  name: string;
  duration: number; // in minutes
  calories: number;
}
